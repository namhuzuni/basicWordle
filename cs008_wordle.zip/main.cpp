#include "Game.h"

int main() {
    //Create a game
   Game game;
}
